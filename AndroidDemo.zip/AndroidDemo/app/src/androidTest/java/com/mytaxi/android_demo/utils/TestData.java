package com.mytaxi.android_demo.utils;

import java.util.ArrayList;

public class TestData {

    public void getData(ArrayList<String> array) {


        ArrayList<String> data = new ArrayList<String>();
        String s1 = "whiteelephant261";
        String s2 = "video1";
        String s3 = "sa";
        String s4 = "Sarah Friedrich";
        data.add(s1);
        data.add(s2);
        data.add(s3);
        data.add(s4);


    }

}

